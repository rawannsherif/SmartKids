
<?php



$connection=mysqli_connect('localhost','root','','nursery');

?>